package foo.johny.servlet.model;

public class Livro {

}
