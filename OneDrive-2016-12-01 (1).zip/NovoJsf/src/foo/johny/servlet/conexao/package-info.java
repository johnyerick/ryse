/**
 * 
 */
/**
 * @author aluno
 *
 */
package foo.johny.servlet.conexao;