package foo.johny.servlet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import foo.johny.servlet.conexao.ConnectionFactory;
import foo.johny.servlet.model.Livro;


	public class AdicionarDAO {
		
		public static boolean adicionar(Livro livro){
			boolean retorno = false;
			Connection con = new ConnectionFactory().getConnection();
			
			try {
			System.out.println("Adicionando..."+livro.getNome());
			retorno = true;
			
			String sql=" INSERT INTO contato "+"(nome, email ) VALUES (?, ?)";
			
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, livro.getNome());
			ps.setString(2, livro.getEmail());
			ps.executeQuery();
			
		} catch(Exception e){
			System.out.println("Erro ao adicionar Contato : "+ livro.getNome()+e.getMessage());
			
		}
			return retorno;


		}
	}

