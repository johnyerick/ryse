package foo.johny.servlet.dao;

public class DeletarDAO {

}
