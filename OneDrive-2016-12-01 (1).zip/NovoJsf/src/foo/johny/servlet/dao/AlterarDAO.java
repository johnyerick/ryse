package foo.johny.servlet.dao;

public class AlterarDAO {

}
