
package foo.johny.conexao;

public class Constantes {
	public static final String DB_DRIVER = "org.postgresql.Driver";
	public static final String DB_NAME = "Johny";
	public static final String DB_CONNECTION = "jdbc:postgresql://127.0.0.1:5432/"
			+ DB_NAME;
	public static final String DB_USER = "postgres";
	public static final String DB_PASSWORD = "java";
}
