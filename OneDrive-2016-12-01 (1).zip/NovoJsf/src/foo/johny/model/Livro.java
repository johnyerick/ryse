package foo.johny.model;

public class Livro {

}
