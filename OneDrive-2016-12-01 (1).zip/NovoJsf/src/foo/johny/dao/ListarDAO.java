package foo.johny.dao;

public class ListarDAO {

}
