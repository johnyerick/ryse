package foo.johny.dao;

public class AlterarDAO {

}
