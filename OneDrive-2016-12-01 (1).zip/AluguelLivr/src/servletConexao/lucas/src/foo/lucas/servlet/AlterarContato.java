package foo.lucas.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import foo.lucas.servlet.dao.AlterarDAO;
import foo.lucas.servlet.model.Contato;

public class AlterarContato extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
		@Override
		protected void service(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {
			
			
			
			PrintWriter out = response.getWriter();
			
			out.println("<html>");
			out.println("<body>");
			
			
			boolean ValidarDados=request.getParameter("email").isEmpty()?false:true;
			
			if(ValidarDados){
				Contato contato = new Contato();
				contato.setNome(request.getParameter("nome"));
				contato.setEmail(request.getParameter("email"));
				
				if(AlterarDAO.alterar(contato)){
					out.println("<h1>Contato Alterado pela Servlet</h1>");
					out.println("<p>Nome:"+contato.getNome()+"</p>");
					out.println("<p>Email:"+contato.getEmail()+"</p>");
				}else{
					out.println("<h1>Erro ao alterar contato no DB");
				}
				
			}
			
			out.println("</body>");
			out.println("</html>");
			
		}
}
