package foo.maddo.model;

public class Conversor {
	private double celsius;
	private double fahrenheit;
	private boolean inicial = true;

	public double getCelsius() {
		return celsius;
	}

	public void setCelsius(double celsius) {
		this.celsius = celsius;
	}

	public double getFahrenheit() {
		return fahrenheit;
	}

	public boolean isInicial() {
		return inicial;
	}

	public void setInicial(boolean inicial) {
		this.inicial = inicial;
	}

	public void setFahrenheit(double fahrenheit) {
		this.fahrenheit = fahrenheit;
	}

	public String limpar() {
		String retorno = "resetar";
		inicial = true;
		fahrenheit = 0;
		celsius = 0;
		return retorno;
	}

	public String converterTemperatura() {
		inicial = false;
		fahrenheit = (celsius * 9 / 5) + 32;
		return "calculado";
	}
}
