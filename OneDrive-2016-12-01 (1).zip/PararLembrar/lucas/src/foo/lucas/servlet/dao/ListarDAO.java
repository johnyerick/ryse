package foo.lucas.servlet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import foo.lucas.servlet.conexao.ConnectionFactory;
import foo.lucas.servlet.model.Contato;

public class ListarDAO {
	
	 public static List<Contato> listar()  {

		  String sql = "select * from contato";

		  List<Contato> lista = new ArrayList<Contato>();

		  Connection con = new ConnectionFactory().getConnection();

		  try {
		   PreparedStatement stmt = con.prepareStatement(sql);
		   ResultSet rs = stmt.executeQuery();

		   while (rs.next()) {
		    Contato contato = new Contato();

		    contato.setNome(rs.getString("nome"));
		    contato.setEmail(rs.getString("email"));
		    lista.add(contato);
		   }

		   stmt.close();
		   rs.close();
		   con.close();
		   
		  } catch (Exception e) {
		   System.out.println(e.getMessage());
		  }
		  
		  return lista;

		 }

		}

