package foo.johny.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import foo.johny.servlet.dao.DeletarDAO;
import foo.johny.servlet.model.Contato;

public class DeletarContato extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<body>");
		
		boolean dadosValidados = request.getParameter("email").isEmpty()?false:true;
		
		if(dadosValidados){
			Contato contato = new Contato();
			contato.setEmail(request.getParameter("email"));
		if(DeletarDAO.deletar(contato)){
			out.println("<h1>Contato Deletado pela Servlet</h1>");
			out.println("<p>Email:"+contato.getEmail());
		}else{
		out.println("<h1>Falha ao deletar contato</h1>");
		out.println("<p>Email:"+contato.getEmail()+"</p>");
	}
		
		}
		out.println("</body>");
		out.println("</html>");
	}
}
