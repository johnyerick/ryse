package foo.johny.servlet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import foo.johny.servlet.conexao.ConnectionFactory;
import foo.johny.servlet.model.Contato;

public class DeletarDAO {
	public static boolean deletar(Contato contato){
		boolean retorno = false;
		Connection con = new ConnectionFactory().getConnection();
		
		try {
		
		retorno = true;
		
		String sql=" DELETE from contato WHERE email=?";
		
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, contato.getEmail());
		
		ps.executeQuery();
		
	} catch(Exception e){
		System.out.println(e.getMessage());
		
	}
		return retorno;


	}
}
