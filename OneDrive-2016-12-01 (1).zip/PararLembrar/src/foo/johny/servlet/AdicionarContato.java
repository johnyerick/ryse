package foo.johny.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import foo.johny.servlet.dao.AdicionarDAO;
import foo.johny.servlet.model.Contato;

public class AdicionarContato extends HttpServlet{
	
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		Contato contato = new Contato();
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<body>");
		//Validacao
		
		boolean dadosValidados = request.getParameter("nome").isEmpty() ? false:true;
		
		if(dadosValidados){
			contato.setNome(request.getParameter("nome"));
			contato.setEmail(request.getParameter("email"));
		
		if(AdicionarDAO.adicionar(contato)){
			out.println("<h1>Contato Cadastrado pela Servlet</h1>");
			out.println("<p>Nome: "+contato.getNome()+"</p>");
			out.println("<p>E-mail: "+contato.getEmail()+"</p>");
			
		}else{
			out.println("<h1>Erro ao adicionar contato no DB</h1>");
		}
			
		
		}else{
			out.println("<h1>Dados do Contato N�o Informados</h1>");
		}
		out.println("</body>");
		out.println("</html>");
	}
	
	
	
	

}
