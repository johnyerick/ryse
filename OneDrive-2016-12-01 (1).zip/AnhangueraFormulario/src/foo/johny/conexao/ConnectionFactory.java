package foo.johny.conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
	
	Connection con;

	 public ConnectionFactory() {
	  System.out.println("Criada Instancia ConnectionFactory()");
	 }

	 public Connection getConnection() {

	  try {
	   Class.forName(Constantes.DB_DRIVER);
	   System.out
	     .println("getConnection() - Drive postgresql registrado ");
	  } catch (Exception e) {
	   System.out.println("getConnection() - Drive nao registrado "
	     + e.getMessage());
	  }

	  try {
	   System.out
	     .println("getConnection() - Conectando ao Banco de Dados ");
	   con = DriverManager.getConnection(Constantes.DB_CONNECTION,
	     Constantes.DB_USER, Constantes.DB_PASSWORD);
	  } catch (SQLException e) {
	   System.out
	     .println("getConnection() - Erro ao Conectar ao Bando de Dados "
	       + e.getMessage());
	  }

	  return con;
	 }

}