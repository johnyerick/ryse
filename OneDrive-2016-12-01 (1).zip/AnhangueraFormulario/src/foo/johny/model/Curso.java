package foo.johny.model;

public class Curso {
	private String cursoNome;
	private String tipoModalidade;
	private String valor;
	private String fies;
	public String getTipoModalidade() {
		return tipoModalidade;
	}
	public void setTipoModalidade(String tipoModalidade) {
		this.tipoModalidade = tipoModalidade;
	}
	public String getValor() {
		return valor;
	}
	public void setValor(String valor) {
		this.valor = valor;
	}
	public String getFies() {
		return fies;
	}
	public void setFies(String fies) {
		this.fies = fies;
	}
	
	private String per�odo;
	public String getPer�odo() {
		return per�odo;
	}
	public void setPer�odo(String per�odo) {
		this.per�odo = per�odo;
	}
	public String getCursoNome() {
		return cursoNome;
	}
	public void setCursoNome(String cursoNome) {
		this.cursoNome = cursoNome;
	}
}
