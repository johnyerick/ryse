/**
 * 
 */
/**
 * @author aluno
 *
 */
package foo.johny.model;