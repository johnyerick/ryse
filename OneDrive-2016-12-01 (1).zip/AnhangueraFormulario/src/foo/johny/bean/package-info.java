/**
 * 
 */
/**
 * @author aluno
 *
 */
package foo.johny.bean;