package foo.johny.bean;


import foo.johny.model.DadosAluno;


public class DadosAlunoOne {

	private DadosAluno dadosAluno;
	public DadosAlunoOne (){ 
		dadosAluno = new DadosAluno(); 
	}
	
	
	
	public DadosAluno getDadosAluno() {
		return dadosAluno;
	}
	public void setDadosAluno(DadosAluno dadosAluno) {
		this.dadosAluno = dadosAluno;
	}

	public String buscar () {
		dadosAluno.setInicial(true);
		
		return null;
		
	}
}
