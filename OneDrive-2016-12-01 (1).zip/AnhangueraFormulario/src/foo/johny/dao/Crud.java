package foo.johny.dao;

public interface Crud <T>{
	
	 boolean inserir (T t);
	

}
