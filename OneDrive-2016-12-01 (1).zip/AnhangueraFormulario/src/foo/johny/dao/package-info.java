/**
 * 
 */
/**
 * @author aluno
 *
 */
package foo.johny.dao;