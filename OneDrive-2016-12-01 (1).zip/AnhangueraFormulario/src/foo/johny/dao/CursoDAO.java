
package foo.johny.dao;

	import java.sql.Connection;
import java.sql.PreparedStatement;

	import foo.johny.conexao.ConnectionFactory;
import foo.johny.model.Curso;

	public class CursoDAO implements  Crud<Curso> {
		public boolean inserir(Curso t) {
			boolean retorno = false;

			Connection con = new ConnectionFactory().getConnection();

			try {
				System.out.println("Adicionando...." + t.getCursoNome());
				retorno = true;

				String sql = "INSERT INTO curso "
						+ "(nomeCurso , valor,) VALUES (?,?)";

				PreparedStatement ps = con.prepareStatement(sql);
				
				ps.setString(1, t.getCursoNome());
				ps.setString(2, t.getTipoModalidade());
				ps.setString(3, t.getPer�odo());
				ps.setString(4, t.getValor());
				ps.setString(5, t.getFies());

				

				ps.execute();
				ps.close();
				con.close();

			} catch (Exception e) {
				System.out.println("Erro ao adicionar: " + t.getCursoNome() + " " + e.getMessage());
			}

			return retorno;
		}

	}



