/**
 * 
 */
/**
 * @author aluno
 *
 */
package foo.Johny.model;