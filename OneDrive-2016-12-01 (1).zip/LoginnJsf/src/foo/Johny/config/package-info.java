/**
 * 
 */
/**
 * @author aluno
 *
 */
package foo.Johny.config;