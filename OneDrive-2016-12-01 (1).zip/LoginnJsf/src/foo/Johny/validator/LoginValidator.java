package foo.Johny.validator;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

public class LoginValidator implements Validator {

	@Override
	public void validate(FacesContext context, UIComponent component, Object obj)
			throws ValidatorException {
		// TODO Auto-generated method stub
		String usuario = (String) obj;
		if (!usuario.equalsIgnoreCase("fabrica")) {
			FacesMessage message = new FacesMessage();
			message.setDetail("Login" + usuario + "inexistente");
			message.setSummary("Usuario nao existe" + "- Login incorreto");
			message.setSeverity(FacesMessage.SEVERITY_ERROR);
			throw new ValidatorException(message);
		}
	}

}
